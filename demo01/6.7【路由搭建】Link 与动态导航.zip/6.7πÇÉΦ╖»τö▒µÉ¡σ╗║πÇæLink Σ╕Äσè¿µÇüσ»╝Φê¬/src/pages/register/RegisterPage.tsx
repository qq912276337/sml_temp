import React from "react";

export const RegisterPage : React.FC = () => {
    return <h1>注册页面</h1>;
}