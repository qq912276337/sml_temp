export * from './home'
export * from './register'
export * from './signIn'
export * from './detail'