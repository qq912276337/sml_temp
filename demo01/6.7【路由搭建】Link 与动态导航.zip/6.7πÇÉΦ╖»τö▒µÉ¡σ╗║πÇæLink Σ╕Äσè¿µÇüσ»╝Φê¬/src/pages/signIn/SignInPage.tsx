import React from "react";

export const SignInPage : React.FC = (props) => {
    console.log(props)
    return <h1>登录页面</h1>;
}